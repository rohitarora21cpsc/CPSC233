# CPSC233 - T08G04
This is an animation based project in which two users are able to play the T-Rex Run game. This is runner game in which the user is a dinosaur that must avoid obtacles by jumping and duking. If the dinosaur hits an obtacle the game ends.
# Demo 1
Demo 1 version of this project can be found in master branch from this repository.
To use Demo 1 compile Game, Player and Obstacles classes and then run Game class as follows:
```bash
javac Game.java
```
```bash
javac Player.java
```
```bash
javac Obstacles.java
```
```bash
java Game
```
